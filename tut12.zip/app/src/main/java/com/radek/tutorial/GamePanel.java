package com.radek.tutorial;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import static java.lang.StrictMath.abs;

/**
 * Created by Radek on 2017-11-11.
 */

public class GamePanel extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread thread;
    private Rect r = new Rect();

    private ArrayList<Obstacle> dots;
    private ArrayList<Obstacle> dots2;
    private ArrayList<Obstacle> dots3;
    private int newDotId;
    private int newDotIdBlue;
    private int newDotIdPurple;

    private RectPlayer player;
    private RectPlayer line;
    //private Point playerPoint;
    private Point linePoint;
    //private ObstacleManager obstacleManager;

    int marginLeft = 40;
    int marginUp = 200;

    private boolean gameOver = false;
    private int newLevel = -1;
    //private boolean movingPlayer = false;
    private long gameOverTime;
    private long newLevelTime;
    private long startGameTime;
    private boolean levelCompleted = false;
    private boolean nextLevel = false;

    private boolean levelIsScreen = false;

    private int currentLevelX1 = marginLeft;
    private int currentLevelX2 = marginLeft;
    private int currentLevelX3 = marginLeft;
    private int currentLevelY1 = 410;
    private int currentLevelY2 = 710;
    private int currentLevelY3 = 1010;

    private int currentDotX = marginLeft, currentDotY = 410;
    private int targetDotX=700, targetDotY=600;
    private int drawnX=marginLeft;
    private int drawnY;
    private boolean drawingEnabled = false;
    private int directionDrawingX = 1;//right
    private int directionDrawingY = 1; // up
    private int actualDotX = marginLeft;
    private int actualDotY = 410;

    private int currentDotXBlue = marginLeft, currentDotYBlue = 710;
    private int targetDotXBlue=700, targetDotYBlue=600;
    private int drawnXBlue=marginLeft;
    private int drawnYBlue;
    private boolean drawingEnabledBlue = false;
    private int directionDrawingXBlue = 1;
    private int directionDrawingYBlue = 1;
    private int actualDotXBlue = marginLeft;
    private int actualDotYBlue = 710;

    private int currentDotXPurple = marginLeft, currentDotYPurple = 1010;
    private int targetDotXPurple=700, targetDotYPurple=600;
    private int drawnXPurple=marginLeft;
    private int drawnYPurple;
    private boolean drawingEnabledPurple = false;
    private int directionDrawingXPurple = 1;//right
    private int directionDrawingYPurple = 1; // up
    private int actualDotXPurple = marginLeft;
    private int actualDotYPurple = 1010;

    private int GRAYLINE = 1;
    private int BLUELINE = 2;
    private int PURPLELINE = 3;

    protected int selectedLine = 1;

    private RectPlayer lightBorder1;
    private RectPlayer lightBorder2;
    private RectPlayer lightBorder3;
    private RectPlayer lightBorder4;

    private RectPlayer line1;
    private RectPlayer line2;
    private RectPlayer line3;

    private int flickeringPhase = 1;

    protected ArrayList<Obstacle> obstacles;
    private int direction;



    private long startTime;
    private long initTime;

    protected float score = 100;
    private float previousScore=100;
    protected float levelTime = 100;
    protected int gameLevel = 1;

    int pause = 0;// -1 pause OFF, 0 pause ON without message, 1 pause ON

    protected int [][] borders = new int [1080] [1920];
    protected int [] [] colors = new int [1080] [1920];

    private ArrayList<RectPlayer>scoringAreas;

    private RectPlayer border1;
    private RectPlayer border2;
    private RectPlayer border3;
    private RectPlayer border4;

    protected RectPlayer startLine1;
    protected RectPlayer startLine2;
    protected RectPlayer startLine3;

    protected boolean startedGame = false;
    private int elapsedPeriod = 0;

    private Screen screen;

    public GamePanel(Context context) {
        super(context);
        dots = new ArrayList<>();
        dots2 = new ArrayList<>();
        dots3 = new ArrayList<>();


        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);
        //obstacleManager = new ObstacleManager();
        obstacleManager();

        lightBorder1 = new RectPlayer(new Rect(20,1440,380,1470), Color.rgb(128,128,128));
        lightBorder2 = new RectPlayer(new Rect(20,1530,380,1560), Color.rgb(128,128,128));
        lightBorder3 = new RectPlayer(new Rect(20,1470,50,1530), Color.rgb(128,128,128));
        lightBorder4 = new RectPlayer(new Rect(350,1470,380,1530), Color.rgb(128,128,128));

        line1 = new RectPlayer(new Rect(50,1470,350,1530), Color.rgb(0,255,255));
        line2 = new RectPlayer(new Rect(390,1470,690,1530), Color.rgb(255,255,0));
        line3 = new RectPlayer(new Rect(730,1470,1030,1530), Color.rgb(255,255,255));

        border1 = new RectPlayer(new Rect(marginLeft-5,marginUp-5,marginLeft+1000,marginUp), Color.rgb(128,128,128));
        border2 = new RectPlayer(new Rect(marginLeft-5,marginUp-5,marginLeft,marginUp+1000), Color.rgb(128,128,128));
        border3 = new RectPlayer(new Rect(marginLeft+1000,marginUp-5,marginLeft+1005,marginUp+1005), Color.rgb(128,128,128));
        border4 = new RectPlayer(new Rect(marginLeft-5,marginUp+1000,marginLeft+1005,marginUp+1005), Color.rgb(128,128,128));

        startLine1 = new RectPlayer(new Rect(marginLeft-25, 400, marginLeft-5, 420), Color.rgb(0,255,255));      //cyan
        startLine2 = new RectPlayer(new Rect(marginLeft-25, 700, marginLeft-5, 720), Color.rgb(255,255,0));        //yellow
        startLine3 = new RectPlayer(new Rect(marginLeft-25, 1000, marginLeft-5, 1020), Color.rgb(255,255,255));      //white

        setFocusable(true);


    }

    public void obstacleManager (){
        startedGame = false;
        elapsedPeriod = 0;

        score = 100;
        gameLevel = 0;
        startTime = initTime = System.currentTimeMillis();

        obstacles = new ArrayList<>();

        //a1 = (ImageView)findViewById(R.id.a1);
        populateObstacles();
        newLevelCreate();

        for (int x = 0; x < 1080; x++)
            for (int y = 0; y < 1920; y ++) {
                borders[x][y] = 0;

                if (x >= marginLeft+1000 || y >= marginUp+1000 || x <= marginLeft || y <= marginUp)
                    borders[x][y] =1;
            }
    }

    private void populateObstacles(){
        int currY = -5 * Constants.SCREEN_HEIGHT / 4;
        direction = 1; // 1 = x+ y+, 2 = x+ y-, 3 = x- y-, 4 = x+ y-
        int xStart = 200;//(int)(Math.random()*(Constants.SCREEN_WIDTH - playerGap));
        currY = 400;
        obstacles.add(new Obstacle(10, Color.rgb(220,220,220), xStart, currY, 7, direction));
    }

    public void reset (){
        int limit;
        selectedLine = 1;
        pause = 0;
        startedGame = false;

        newDotId = 0;
        newDotIdBlue = 0;
        newDotIdPurple = 0;

        drawnX = currentDotX = actualDotX = targetDotX =currentLevelX1;
        drawnXBlue = currentDotXBlue = actualDotXBlue = targetDotXBlue = currentLevelX2;
        drawnXPurple = currentDotXPurple = actualDotXPurple =targetDotXPurple= currentLevelX3;
        currentDotY = actualDotY = targetDotY = currentLevelY1;
        currentDotYBlue = actualDotYBlue = targetDotYBlue=currentLevelY2;
        currentDotYPurple = actualDotYPurple = targetDotYPurple=currentLevelY3;

        limit = dots.size();
        for (int i = 0; i < limit; i ++) {
            dots.remove(0);
        }

        limit = dots2.size();
        for (int i = 0; i < limit; i ++) {
            dots2.remove(0);
        }

        limit = dots3.size();
        for (int i = 0; i < limit; i ++) {
            dots3.remove(0);
        }

        for (int x = 0; x < 1080; x++)
            for (int y = 0; y < 1920; y ++) {
                borders[x][y] = 0;

                if (x >= marginLeft+1000 || y >= marginUp+1000 || x <= marginLeft || y <= marginUp)
                    borders[x][y] =1;
            }

        for( int x = 0; x < 1080; x ++)
            for (int y = 0; y < 1920; y ++) {
                colors[x][y] = 0;
            }

        if (gameOver){
            gameLevel = 0;
            //newLevel = 0;
            newLevelCreate();
            gameOver = false;
            System.out.println("gameOver");
            nextLevel = false;
            score = previousScore = 100;
            newLevelTime = System.currentTimeMillis();
        }else if (newLevel == 0 || !gameOver) {
            newLevelCreate();
        }
    }

    private void newLevelCreate(){
        gameLevel ++;
        scoringAreas = new ArrayList<>();
        levelTime = 400;

        int limit = obstacles.size();
        for (int i = 0; i < limit; i ++){
            obstacles.remove(0);
        }

        if (gameLevel == 1) {
            addRectangleArea(0,0,250,250,3);
            addRectangleArea(400,0,600,400,3);
            addRectangleArea(750,0,1000,250,3);
            addRectangleArea(0,400,400,600,3);
            addRectangleArea(600,400,1000,600,3);
            addRectangleArea(0,750,250,1000,3);
            addRectangleArea(400,600,600,1000,3);
            addRectangleArea(750,750,1000,1000,3);

            addRectangleArea(0,0,150,150,1);
            addRectangleArea(850,0,1000,150,1);
            addRectangleArea(0,850,150,1000,1);
            addRectangleArea(850,850,1000,1000,1);
            //obstacles.add(new Obstacle(10, Color.rgb(220,220,220), 200, 400, 7, 1));
            instertBall (10, 220, 220, 220, 100, 500, 7, 1);
        }

        if (gameLevel == 2) {
            //addRectangleArea (300,300,600,600,2);
            //addRectangleArea (500,400,600,500,1);
            screen = new Screen(BitmapFactory.decodeResource(getResources(), R.drawable.screen2), 1000, 1000, 1);
            levelIsScreen = true;
            //obstacles.add(new Obstacle(10, Color.rgb(220,220,220), 540, 1000, 7, 2));
            instertBall(10,220,220,220,500,500,7,2);
        }

        if (gameLevel == 3) {
            levelIsScreen = false;
            addRectangleArea (300,300,700,700,2);
            addRectangleArea (500,400,600,500,1);
            addRectangleArea (500,400,600,500,1);
            //obstacles.add(new Obstacle(10, Color.rgb(220,220,220), 340, 1000, 7, 3));
            //obstacles.add(new Obstacle(10, Color.rgb(250,250,250), 540, 1000, 7, 2));
            instertBall(10,220,220,220,400,500,7,3);
            instertBall(10,250,250,250,500,500,7,2);
        }
    }

    private void instertBall (int height, int colA, int colB, int colC, int startX, int startY, int size, int direction){
        obstacles.add(new Obstacle(height, Color.rgb(colA,colB,colC), startX+marginLeft, startY+marginUp, size, direction));
    }

    private void addRectangleArea (int startX, int startY, int endX, int endY, int colorCode){
        int r=255, g=255, b=255;

        if (colorCode == 1) {
            r = 190;
            g = 0;
            b = 0;
        }
        else if (colorCode == 2) {
            r = 210;
            g = 0;
            b = 210;
        }
        else if (colorCode == 3) {
            r = 0;
            g = 0;
            b = 203;
        }

        scoringAreas.add(new RectPlayer(new Rect(startX+marginLeft, startY+marginUp, endX+marginLeft, endY+marginUp), Color.rgb(r, g, b)));

        for( int x = 0; x < 1080; x ++)
            for (int y = 0; y < 1920; y ++) {
                if (x >= startX+marginLeft && y >= startY+marginUp & x <= endX+marginLeft && y<= endY+marginUp)
                        colors [x][y] = colorCode; // 1 = red color code
                }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int widht, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread = new MainThread(getHolder(), this);

        thread.setRunning(true);
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
            } catch (Exception e) {
                e.printStackTrace();
                retry = false;
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        int xTouch = (int)event.getX();
        int yTouch = (int)event.getY();
        boolean dotAllowed = false;

        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                if(gameOver && System.currentTimeMillis() - gameOverTime >= 2000){
                    System.out.println(System.currentTimeMillis() - gameOverTime);
                    reset();
                    newLevel = -1;
                }
                else if (newLevel == 0 && System.currentTimeMillis() - newLevelTime >= 2000){           // if level is completed
                    reset();
                    newLevel = -1;
                    levelCompleted = false;
                    nextLevel = true;
                }else if (!gameOver && System.currentTimeMillis() - newLevelTime >= 1000){
                    if (startedGame == true && xTouch >= marginLeft && xTouch <= marginLeft+1000 && yTouch >= marginUp && yTouch <= marginUp + 1000 && borders[xTouch][yTouch] != 1) {
                        dotAllowed = true;

                        if (pause == 0)
                        pause = -1; // pause OFF
                    }

                    if (dotAllowed == true) {
                        if (selectedLine == GRAYLINE) {
                            drawnX = currentDotX = actualDotX;
                            drawnY = currentDotY = actualDotY;
                            targetDotX = xTouch;
                            targetDotY = yTouch;
                            drawingEnabled = true;

                            if (targetDotX > currentDotX)
                                directionDrawingX = 1;       // right
                            else
                                directionDrawingX = 2;

                            if (targetDotY > currentDotY)
                                directionDrawingY = 1;      // up
                            else
                                directionDrawingY = 2;
                        } else if (selectedLine == BLUELINE) {
                            drawnXBlue = currentDotXBlue = actualDotXBlue;
                            drawnYBlue = currentDotYBlue = actualDotYBlue;
                            targetDotXBlue = xTouch;
                            targetDotYBlue = yTouch;
                            drawingEnabledBlue = true;

                            if (targetDotXBlue > currentDotXBlue)
                                directionDrawingXBlue = 1;       // right
                            else
                                directionDrawingXBlue = 2;

                            if (targetDotYBlue > currentDotYBlue)
                                directionDrawingYBlue = 1;      // up
                            else
                                directionDrawingYBlue = 2;
                        } else if (selectedLine == PURPLELINE) {
                            drawnXPurple = currentDotXPurple = actualDotXPurple;
                            drawnYPurple = currentDotYPurple = actualDotYPurple;
                            targetDotXPurple = xTouch;
                            targetDotYPurple = yTouch;
                            drawingEnabledPurple = true;

                            if (targetDotXPurple > currentDotXPurple)
                                directionDrawingXPurple = 1;       // right
                            else
                                directionDrawingXPurple = 2;

                            if (targetDotYPurple > currentDotYPurple)
                                directionDrawingYPurple = 1;      // up
                            else
                                directionDrawingYPurple = 2;
                        }
                    } else if (xTouch >= 390 && xTouch <= 690 && yTouch >= 1400 && yTouch <= 1600)
                        selectedLine = BLUELINE;
                    else if (xTouch >= 50 && xTouch <= 350 && yTouch >= 1400 && yTouch <= 1600)
                        selectedLine = GRAYLINE;
                    else if (xTouch >= 730 && xTouch <= 1030 && yTouch >= 1400 && yTouch <= 1600)
                        selectedLine = PURPLELINE;
                    else if (xTouch <= 350 && yTouch > 1600) {
                        if (pause == -1)
                            pause = 1;
                        else if (pause == 1)
                            pause = -1;
                    }
                    else if (startedGame == false && xTouch >= 300 && xTouch <= 800 && yTouch >= 600 && yTouch <= 900) {
                        startedGame = true;
                        newLevel = -2;
                        newLevelTime = System.currentTimeMillis();
                    }
                }
                break;
        }

        return true;
    }

    public void update(){
        if(!gameOver) {
            update2();

            if (levelIsScreen)
                screen.update();

            if (levelTime <= 0) {
                if (score - previousScore >= 0 && levelCompleted == false) {
                    newLevel = 0;
                    newLevelTime = System.currentTimeMillis();
                    //System.out.println(newLevelTime);
                    levelCompleted = true;
                    previousScore = score;
                } else if (levelCompleted == false){
                    gameOverTime = System.currentTimeMillis();
                    gameOver = true;
                    startedGame = false;
                }
            }

            if (startedGame) {
                int limit = obstacles.size();

                for (int i=0; i < limit; i++) {

                    int x = obstacles.get(i).getRectangle().centerX();
                    int y = obstacles.get(i).getRectangle().centerY();

                    if (colors[x][y] == 1 && newLevel != 0 && pause == -1)
                        score += 0.2;
                    else if (colors[x][y] == 2 && newLevel != 0 && pause == -1)
                        score -= 0.2;

                    if (pause == -1 && levelCompleted == false)
                        levelTime -= 0.2;
                }
            }
        }
        else
            update2();
    }

    public void update2 (){
        int elapsedTime = (int)(System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();
        int speed = 5;
        int obstacleX, obstacleY;

        if (startedGame == true && pause == -1) {
            //levelTime -= 0.2;

            for (Obstacle ob : obstacles) {
                // * elapsedTime);

                obstacleX = ob.getRectangle().centerX();
                obstacleY = ob.getRectangle().centerY();

                int border = 0;

                if (ob.getDirection() == 1)
                    border = borders[obstacleX + (int) speed][obstacleY + (int) speed];
                else if (ob.getDirection() == 2)
                    border = borders[obstacleX + (int) speed][obstacleY - (int) speed];
                else if (ob.getDirection() == 3)
                    border = borders[obstacleX - (int) speed][obstacleY - (int) speed];
                else if (ob.getDirection() == 4)
                    border = borders[obstacleX - (int) speed][obstacleY + (int) speed];

                if (border == 0) {      // empty space
                    if (ob.getDirection() == 1) {
                        ob.incrementX(speed);
                        ob.incrementY(speed);
                    } else if (ob.getDirection() == 2) {
                        ob.incrementX(speed);
                        ob.decreaseY(speed);
                    } else if (ob.getDirection() == 3) {
                        ob.decreaseX(speed);
                        ob.decreaseY(speed);
                    } else if (ob.getDirection() == 4) {
                        ob.decreaseX(speed);
                        ob.incrementY(speed);
                    }
                } else {
                    if (ob.getDirection() == 1 && borders[obstacleX + (int) speed][obstacleY - (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY + (int) speed] >= 1) {
                        ob.setDirection(4);
                    } else if (ob.getDirection() == 1 && borders[obstacleX - (int) speed][obstacleY + (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY + (int) speed] >= 1) {
                        ob.setDirection(2);
                    } else if (ob.getDirection() == 1)
                        ob.setDirection(3);
                    else if (ob.getDirection() == 2 && borders[obstacleX + (int) speed][obstacleY - (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY + (int) speed] >= 1) {
                        ob.setDirection(3);
                    } else if (ob.getDirection() == 2 && borders[obstacleX - (int) speed][obstacleY - (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY - (int) speed] >= 1) {
                        ob.setDirection(1);
                    } else if (ob.getDirection() == 2)
                        ob.setDirection(4);
                    else if (ob.getDirection() == 3 && borders[obstacleX - (int) speed][obstacleY + (int) speed] >= 1 && borders[obstacleX - (int) speed][obstacleY - (int) speed] >= 1) {
                        ob.setDirection(2);
                    } else if (ob.getDirection() == 3 && borders[obstacleX - (int) speed][obstacleY - (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY - (int) speed] >= 1) {
                        ob.setDirection(4);
                    } else if (ob.getDirection() == 3)
                        ob.setDirection(1);
                    else if (ob.getDirection() == 4 && borders[obstacleX - (int) speed][obstacleY + (int) speed] >= 1 && borders[obstacleX + (int) speed][obstacleY + (int) speed] >= 1) {
                        ob.setDirection(3);
                    } else if (ob.getDirection() == 4 && borders[obstacleX - (int) speed][obstacleY + (int) speed] >= 1 && borders[obstacleX - (int) speed][obstacleY - (int) speed] >= 1) {
                        ob.setDirection(1);
                    } else
                        ob.setDirection(2);
                }
            }
        }
    }

    @Override
    public void draw(Canvas canvas)
    {
        int colA = 0, colB = 0, colC = 0;

        super.draw(canvas);

        canvas.drawColor(Color.rgb(16,16,16));

        if (levelIsScreen == true)
            screen.draw(canvas);

        draw2(canvas);

        if (startedGame == true || gameOver) {
            for (int i = 0; i < 10; i++) {
                if (drawingEnabled == true && pause == -1) {// && obstacleManager.borders[drawnX][drawnY] != 2) {
                    int equationType;

                    if (abs(targetDotX - currentDotX) > abs(targetDotY - currentDotY))
                        equationType = 2; // y counting
                    else
                        equationType = 1; // x counting

                    if (equationType == 1 && currentDotY != targetDotY)
                        drawnX = (drawnY - currentDotY) * (currentDotX - targetDotX) / (currentDotY - targetDotY) + currentDotX;
                    else if (equationType == 2 && targetDotX != currentDotX)
                        drawnY = drawnX * (currentDotY - targetDotY) / (currentDotX - targetDotX) + (currentDotY - currentDotX * (currentDotY - targetDotY) / (currentDotX - targetDotX));

                    dots.add(new Obstacle(50, Color.rgb(0, 255, 255), drawnX, drawnY, 4, 1));

                    for (int k = -3; k < 3; k++)
                        for (int l = -3; l < 3; l++)
                            if (borders[drawnX + k][drawnY + l] != 1)
                                borders[drawnX + k][drawnY + l] += 2;

                    int dotId = dots.size();
                    newDotId = dotId;
                    actualDotX = drawnX;
                    actualDotY = drawnY;

                    if (dotId > 500) {

                        for (int k = -3; k < 3; k++)
                            for (int l = -3; l < 3; l++)
                                if (borders[dots.get(0).getStartX() + k][dots.get(0).getStartY() + l] >= 2)
                                    borders[dots.get(0).getStartX() + k][dots.get(0).getStartY() + l] -= 2;

                        dots.remove(0);
                    }

                    if (drawnX == targetDotX) {
                        currentDotX = targetDotX;
                        currentDotY = targetDotY;
                        drawingEnabled = false;
                    } else {
                        if (equationType == 2) {
                            if (directionDrawingX == 1)
                                drawnX++;
                            else
                                drawnX--;
                        } else {
                            if (directionDrawingY == 1)
                                drawnY++;
                            else
                                drawnY--;
                        }
                    }
                }
            }

            for (int i = 0; i < 10; i++) {
                if (drawingEnabledBlue == true && pause == -1) {// && obstacleManager.borders[drawnX][drawnY] != 2) {
                    int equationType;

                    if (abs(targetDotXBlue - currentDotXBlue) > abs(targetDotYBlue - currentDotYBlue))
                        equationType = 2; // y counting
                    else
                        equationType = 1; // x counting

                    if (equationType == 1 && currentDotYBlue != targetDotYBlue)
                        drawnXBlue = (drawnYBlue - currentDotYBlue) * (currentDotXBlue - targetDotXBlue) / (currentDotYBlue - targetDotYBlue) + currentDotXBlue;
                    else if (equationType == 2 && targetDotXBlue != currentDotXBlue)
                        drawnYBlue = drawnXBlue * (currentDotYBlue - targetDotYBlue) / (currentDotXBlue - targetDotXBlue) + (currentDotYBlue - currentDotXBlue * (currentDotYBlue - targetDotYBlue) / (currentDotXBlue - targetDotXBlue));

                    dots2.add(new Obstacle(50, Color.rgb(255, 255, 0), drawnXBlue, drawnYBlue, 4, 1));

                    for (int k = -3; k < 3; k++)
                        for (int l = -3; l < 3; l++)
                            if (borders[drawnXBlue + k][drawnYBlue + l] != 1)
                                borders[drawnXBlue + k][drawnYBlue + l] += 2;

                    int dotId = dots2.size();
                    newDotIdBlue = dotId;
                    actualDotXBlue = drawnXBlue;
                    actualDotYBlue = drawnYBlue;

                    if (dotId > 500) {
                        for (int k = -3; k < 3; k++)
                            for (int l = -3; l < 3; l++)
                                if (borders[dots2.get(0).getStartX() + k][dots2.get(0).getStartY() + l] >= 2)
                                    borders[dots2.get(0).getStartX() + k][dots2.get(0).getStartY() + l] -= 2;

                        dots2.remove(0);
                    }

                    if (drawnXBlue == targetDotXBlue) {
                        currentDotXBlue = targetDotXBlue;
                        currentDotYBlue = targetDotYBlue;
                        drawingEnabledBlue = false;
                    } else {
                        if (equationType == 2) {
                            if (directionDrawingXBlue == 1)
                                drawnXBlue++;
                            else
                                drawnXBlue--;
                        } else {
                            if (directionDrawingYBlue == 1)
                                drawnYBlue++;
                            else
                                drawnYBlue--;
                        }
                    }
                }
            }

            for (int i = 0; i < 10; i++) {
                if (drawingEnabledPurple == true && pause == -1) {// && obstacleManager.borders[drawnX][drawnY] != 2) {
                    int equationType;

                    if (abs(targetDotXPurple - currentDotXPurple) > abs(targetDotYPurple - currentDotYPurple))
                        equationType = 2; // y counting
                    else
                        equationType = 1; // x counting

                    if (equationType == 1 && currentDotYPurple != targetDotYPurple)
                        drawnXPurple = (drawnYPurple - currentDotYPurple) * (currentDotXPurple - targetDotXPurple) / (currentDotYPurple - targetDotYPurple) + currentDotXPurple;
                    else if (equationType == 2 && targetDotXPurple != currentDotXPurple)
                        drawnYPurple = drawnXPurple * (currentDotYPurple - targetDotYPurple) / (currentDotXPurple - targetDotXPurple) + (currentDotYPurple - currentDotXPurple * (currentDotYPurple - targetDotYPurple) / (currentDotXPurple - targetDotXPurple));

                    dots3.add(new Obstacle(50, Color.rgb(255, 255, 255), drawnXPurple, drawnYPurple, 4, 1));

                    for (int k = -3; k < 3; k++)
                        for (int l = -3; l < 3; l++)
                            if (borders[drawnXPurple + k][drawnYPurple + l] != 1)
                                borders[drawnXPurple + k][drawnYPurple + l] += 2;

                    int dotId = dots3.size();
                    newDotIdPurple = dotId;
                    actualDotXPurple = drawnXPurple;
                    actualDotYPurple = drawnYPurple;

                    if (dotId > 500) {
                        for (int k = -3; k < 3; k++)
                            for (int l = -3; l < 3; l++)
                                if (borders[dots3.get(0).getStartX() + k][dots3.get(0).getStartY() + l] >= 2)
                                    borders[dots3.get(0).getStartX() + k][dots3.get(0).getStartY() + l] -= 2;

                        dots3.remove(0);
                    }

                    if (drawnXPurple == targetDotXPurple) {
                        currentDotXPurple = targetDotXPurple;
                        currentDotYPurple = targetDotYPurple;
                        drawingEnabledPurple = false;
                    } else {
                        if (equationType == 2) {
                            if (directionDrawingXPurple == 1)
                                drawnXPurple++;
                            else
                                drawnXPurple--;
                        } else {
                            if (directionDrawingYPurple == 1)
                                drawnYPurple++;
                            else
                                drawnYPurple--;
                        }
                    }
                }
            }

            for (int i = 0; i < newDotId - 1; i += 4) {
                dots.get(i).draw(canvas);
            }

            for (int i = 0; i < newDotIdBlue - 1; i += 4) {
                dots2.get(i).draw(canvas);
            }

            for (int i = 0; i < newDotIdPurple - 1; i += 4) {
                dots3.get(i).draw(canvas);
            }

            if (flickeringPhase <= 4)
                colA = colB = colC = 32;
            else if (flickeringPhase <= 8)
                colA = colB = colC = 64;
            else if (flickeringPhase <= 12)
                colA = colB = colC = 96;
            else if (flickeringPhase <= 16)
                colA = colB = colC = 128;
            else if (flickeringPhase <= 20)
                colA = colB = colC = 160;
            else if (flickeringPhase <= 24) {
                colA = colB = colC = 192;
                flickeringPhase = 1;
            }

            flickeringPhase++;

            lightBorder1.setColor(Color.rgb(colA, colB, colC));
            lightBorder2.setColor(Color.rgb(colA, colB, colC));
            lightBorder3.setColor(Color.rgb(colA, colB, colC));
            lightBorder4.setColor(Color.rgb(colA, colB, colC));

            if (selectedLine == 1) {
                lightBorder1.getRectangle().set(20, 1440, 380, 1470);
                lightBorder2.getRectangle().set(20, 1530, 380, 1560);
                lightBorder3.getRectangle().set(20, 1470, 50, 1530);
                lightBorder4.getRectangle().set(350, 1470, 380, 1530);
            } else if (selectedLine == 2) {
                lightBorder1.getRectangle().set(20 + 340, 1440, 380 + 340, 1470);
                lightBorder2.getRectangle().set(20 + 340, 1530, 380 + 340, 1560);
                lightBorder3.getRectangle().set(20 + 340, 1470, 50 + 340, 1530);
                lightBorder4.getRectangle().set(350 + 340, 1470, 380 + 340, 1530);
            } else if (selectedLine == 3) {
                lightBorder1.getRectangle().set(20 + 680, 1440, 380 + 680, 1470);
                lightBorder2.getRectangle().set(20 + 680, 1530, 380 + 680, 1560);
                lightBorder3.getRectangle().set(20 + 680, 1470, 50 + 680, 1530);
                lightBorder4.getRectangle().set(350 + 680, 1470, 380 + 680, 1530);
            }

            if (selectedLine >0) {
                lightBorder1.draw(canvas);
                lightBorder2.draw(canvas);
                lightBorder3.draw(canvas);
                lightBorder4.draw(canvas);
            }

            line1.draw(canvas);
            line2.draw(canvas);
            line3.draw(canvas);


        }

        if (newLevel == 0){
            Paint paint = new Paint();
            paint.setTextSize(100);
            paint.setColor(Color.GREEN);
            //drawCenterText(canvas, paint, "Level completed!");
            canvas.drawText("Level completed!", 200, 500+marginUp, paint);
        }

        if (pause == 1){
            Paint paint = new Paint();
            paint.setTextSize(100);
            paint.setColor(Color.rgb(250,150,0));
            //drawCenterText(canvas, paint, "Pause ON");
            canvas.drawText("Pause ON", 300, 300+marginUp, paint);
        }

        if (newLevel == -1) {
            Paint paint = new Paint();
            paint.setTextSize(100);

            if (elapsedPeriod < 35)
                paint.setColor(Color.rgb(255, 32, 32));
            else
                paint.setColor(Color.rgb(255, 32, 255));

            elapsedPeriod ++;


            if (elapsedPeriod == 70)
                elapsedPeriod = 0;

            if (!nextLevel)
                canvas.drawText("Start Game", 300, 700, paint);
            else
                canvas.drawText("Level " + gameLevel, 400, 700, paint);
        }

        if (gameOver) {
            Paint paint = new Paint();
            paint.setTextSize(100);
            paint.setColor(Color.MAGENTA);
            canvas.drawText("Game Over", 300, 800, paint);
        }
    }

    public void draw2 (Canvas canvas){
        border1.draw(canvas);
        border2.draw(canvas);
        border3.draw(canvas);
        border4.draw(canvas);

        if (startedGame == true || gameOver) {
            //scoringAreaRed1.draw(canvas);

            for (RectPlayer scoringArea : scoringAreas)
                scoringArea.draw(canvas);

            startLine1.draw(canvas);
            startLine2.draw(canvas);
            startLine3.draw(canvas);

            for (Obstacle ob: obstacles)
                ob.draw(canvas);

            Paint paint = new Paint();
            paint.setTextSize(70);

            if(score >= previousScore)
                paint.setColor(Color.rgb(255, 32, 32));
            else
                paint.setColor(Color.rgb(210, 0, 210));

            canvas.drawText("S:" + (int)score, 250, 150, paint);
            paint.setColor(Color.rgb(210, 0, 210));
            canvas.drawText("P:" + (int)previousScore, 500, 150, paint);
            paint.setColor(Color.rgb(128, 64, 64));
            canvas.drawText("L:" + gameLevel, 50, 150, paint);
            paint.setColor(Color.rgb(32, 128, 128));
            canvas.drawText("T:" + (int) levelTime, 850, 150, paint);

            paint.setColor(Color.rgb(250, 160, 0));
            canvas.drawText("PAUSE", 90, 1700, paint);

            paint.setColor(Color.rgb(250, 250, 250));
            canvas.drawText("BONUS", 420, 1700, paint);
        }
    }

    private void drawCenterText(Canvas canvas, Paint paint, String text) {
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.getClipBounds(r);
        int cHeight = r.height();
        int cWidth = r.width();
        paint.getTextBounds(text, 0, text.length(), r);
        float x = cWidth / 2f - r.width() / 2f - r.left;
        float y = cHeight / 2f + r.height() / 2f - r.bottom;
        canvas.drawText(text, x, y, paint);
    }
}