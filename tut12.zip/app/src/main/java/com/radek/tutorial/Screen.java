package com.radek.tutorial;

import android.graphics.Bitmap;
import android.graphics.Canvas;


/**
 * Created by Radek on 2018-01-07.
 */

public class Screen extends GameElement{
    private Bitmap spritesheet;
    private Animation animation = new Animation();
    private long startTime;

    public Screen (Bitmap res, int w, int h, int numFrames){
        x = 40;
        y = 200;
        height = h;
        width = w;
        Bitmap [] image = new Bitmap[numFrames];
        spritesheet = res;

        for (int i = 0; i<image.length; i++){
            image[i] = Bitmap.createBitmap(spritesheet, i*width, 0, width, height);
        }

        animation.setFrames(image);
        animation.setDelay(10);
    }

    public void update (){
        animation.update();
    }

    public void draw (Canvas canvas){
        canvas.drawBitmap(animation.getImage(), x, y, null);

    }
}
